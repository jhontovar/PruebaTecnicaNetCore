# PruebaTecnicaNetCore

-Se Implementa Clean Arquitecture.
-Se usa principios SOLID con la implementacion de Separación de responsabilidades
-Se implementa las Pruebas Unitarias con xUnit